#pragma once
#include <limits>

namespace generics
{
using value_t = int;
constexpr value_t empty_val = -1000000; // if your queue only stores 0..1999
// using value_t = int;

}; // namespace generics